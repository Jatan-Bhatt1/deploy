import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { useTheme } from "../../theme/ThemeContext";

export default function Music() {
  const navigation = useNavigation<any>();
  const { theme } = useTheme();

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={[styles.back, { color: theme.primary }]}>← Back</Text>
      </TouchableOpacity>
      <Text style={[styles.text, { color: theme.text }]}>Music & Dance Activites</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center" },
  text: { fontSize: 22, fontWeight: "600", marginTop: 10 },
  back: { fontSize: 18, color: "#007AFF", position: "absolute", top: 50, left: 20 },
});
