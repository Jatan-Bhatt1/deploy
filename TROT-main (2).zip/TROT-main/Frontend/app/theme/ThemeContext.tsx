import React, { createContext, useContext, useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

type Theme = {
  background: string;
  surface: string;
  text: string;
  muted: string;
  primary: string;
};

const LIGHT_THEME: Theme = {
  background: "#F7F9FC",
  surface: "#ffffff",
  text: "#0f172a",
  muted: "#6b7280",
  primary: "#00e0ff",
};

const DARK_THEME: Theme = {
  background: "#121212",
  surface: "#1e1e1e",
  text: "#ffffff",
  muted: "#9ca3af",
  primary: "#00e0ff",
};

const STORAGE_KEY = "darkMode";

const ThemeContext = createContext<{
  isDark: boolean;
  toggleTheme: () => void;
  theme: Theme;
}>({ 
  isDark: false, 
  toggleTheme: () => {}, 
  theme: LIGHT_THEME 
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        setIsDark(stored === "true");
      } catch {}
    })();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEY, isDark.toString()).catch(() => {});
  }, [isDark]);

  const toggleTheme = () => {
    setIsDark(!isDark);
  };

  const theme = isDark ? DARK_THEME : LIGHT_THEME;

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme, theme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}

export default ThemeProvider;
